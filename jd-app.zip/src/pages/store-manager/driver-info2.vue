<template>
  <div>
    <div class="info">
      <div class="dirver-name">
        <img src="@/assets/u1210.png">
        <span>滴师傅</span>
      </div>
      <div class="driver-number">
        <img src="@/assets/u1151.png">
        <span>137625515155</span>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  name: 'driver-info'
}
</script>
<style lang="scss" scoped>
.info {
  position: relative;
  height: 100px;
  border-top: 1px solid #999;
  border-bottom: 1px solid #999;
  padding-left: 20px;
  font-size: 16px;
}
.info .dirver-name,.info .driver-number {
  position: relative;
  margin-top: 15px;
  height: 30px;
}
.info .dirver-name img,.info .driver-number img {
  position: absolute;
  left: 15px;

}
.info .dirver-name span,.info .driver-number span {
  position: absolute;
  left: 50px;
  top: 2px;
}
</style>