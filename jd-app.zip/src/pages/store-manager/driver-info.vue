<template>
  <div>
    <div class="user">
      <img src="../../assets/u681.jpg" >
    </div>
    <div class="store-info">
      <div class="store-name">
        <img src="@/assets/u1210.png">
        <span>滴师傅</span>
      </div>
      <div class="invite-code">
        <div><img src="@/assets/u1151.png"></div>
        <div><span>手机：123564489</span></div>
      </div>
    </div>
    <div class="last">
      <div class="update-psw">
        <img class="update" src="@/assets/u666.png">
        <span>修改密码</span>
        <img class="right" src="../../assets/右.png">
      </div>
       <div class="login-out">
        <img class="out" src="@/assets/u675.png">
        <span>退出登录</span>
        <img class="right2" src="../../assets/右.png">
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'mine',
  data () {
    return {
      conList: [
        {
          img1: require('../../assets/修改密码.png'),
          label: '修改密码',
          img2: require('../../assets/右.png'),
          toPath: '/change-password'
        }, {
          img1: require('../../assets/退出.png'),
          label: '退出登录',
          img2: require('../../assets/右.png'),
          toPath: '/login'
        }
      ]
    }
  },
  methods: {
    toPage (data) {
      this.$router.push({path: data.toPath})
    }
  }
}
</script>

<style lang="scss" scoped>
  .user {
    img {
        width: 100%;
        height: 135px;
    }
  }
  .store-info {
    position: relative;
    width: 339px;
    height: 70px;
    background-color: rgba(242, 242, 242, 1);
    font-size: 15px;
    padding: 15px 18px;
    .store-name {
      position: relative;
    }
    .store-name img {
      position: absolute;
      
    }
    .store-name span {
      position: absolute;
      left: 35px;
      top: 2px;
    } 
     .invite-code img {
      position: absolute;
      top: 50px;
    }
    .invite-code span {
      position: absolute;
      left: 50px;
      top: 52px;
    }
     .store-addrerss img {
      position: absolute;
      top: 85px;
    }
    .store-addrerss span {
      position: absolute;
      left: 50px;
      top: 87px;
    }
  }
  .last {
    position: relative;
    width: 338px;
    height: 105px;
    font-size: 15px;
    top: 10px;
    .update-psw,.login-out {
      position: relative;
      width: 338px;
      height: 35px;
      line-height: 35px;
      padding: 15px 18px;
      margin-top: 10px;
      background-color: rgba(242, 242, 242, 1);
    }
    .update-psw .update,.login-out .out {
      width: 25px;
      height: 25px;
    }
    .update-psw span,.login-out span {
      position: absolute;
      left: 60px;
      top: 15px;
      font-size: 20px;
    } 
    .update-psw .update,.login-out .out {
      position: absolute;
      top: 20px;
    }
    .update-psw .right,.login-out .right2 {
      position: absolute;
      top: 23px;
      left: 350px;
    }
  }
</style>
